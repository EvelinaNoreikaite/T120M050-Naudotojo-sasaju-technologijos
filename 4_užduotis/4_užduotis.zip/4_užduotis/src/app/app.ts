import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

type NewNote = { title: string; text: string; createdAt: string };
type FirebaseMap = Record<string, NewNote>;

@Component({
  selector: 'app-component',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  template: `
    <div class="notes-container">
      <header class="notes-header">
        <div class="header-content">
          <div class="header-title-wrapper">
            <svg width="50" height="50" viewBox="0 0 240 240" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="70" y="40" width="100" height="160" rx="8" fill="white" stroke="#3B82F6" stroke-width="8"/>
              <circle cx="120" cy="35" r="18" fill="#3B82F6"/>
              <rect x="85" y="80" width="50" height="8" rx="4" fill="#3B82F6"/>
              <rect x="85" y="100" width="50" height="8" rx="4" fill="#3B82F6"/>
              <rect x="85" y="120" width="50" height="8" rx="4" fill="#3B82F6"/>
              <circle cx="150" cy="105" r="15" fill="none" stroke="#3B82F6" stroke-width="6"/>
              <rect x="145" y="135" width="20" height="8" rx="4" fill="#3B82F6"/>
            </svg>
            <h1 class="header-title">Mano Užrašai</h1>
          </div>
        </div>
      </header>

      <main class="main-content">
        <div class="add-note-card">
          <h2 class="add-note-title">
            <span class="plus-icon">+</span> Pridėti naują užrašą
          </h2>
          <div>
            <div class="form-group">
              <label for="title" class="form-label">Pavadinimas</label>
              <input
                id="title"
                type="text"
                [(ngModel)]="title"
                placeholder="Įveskite užrašo pavadinimą..."
                class="form-input"
              />
            </div>
            
            <div class="form-group">
              <label for="text" class="form-label">Tekstas</label>
              <textarea
                id="text"
                [(ngModel)]="text"
                placeholder="Įveskite užrašo tekstą..."
                rows="4"
                class="form-textarea"
              ></textarea>
            </div>
            
            <button (click)="addNote()" class="add-button">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Pridėti užrašą
            </button>
          </div>
        </div>

        <div class="notes-count-card">
          <p class="notes-count-text">
            Viso užrašų: <span class="notes-count-number">{{ notes.length }}</span>
          </p>
        </div>

        <div *ngIf="notes.length === 0" class="empty-state">
          <div class="empty-icon">📭</div>
          <h3 class="empty-title">Nėra užrašų</h3>
          <p class="empty-description">Pridėkite savo pirmą užrašą naudodami formą aukščiau!</p>
        </div>

<div *ngIf="notes.length > 0" class="notes-grid">
  <div *ngFor="let note of notes" class="note-card">
    <div class="note-header">
      <!-- title (view vs edit) -->
      <h3 class="note-title" *ngIf="editingId !== note.id">{{ note.title }}</h3>
      <input
        *ngIf="editingId === note.id"
        [(ngModel)]="editTitle"
        class="form-input"
        placeholder="Pavadinimas"
      />

      <!-- actions -->
      <div style="display:flex; gap:.4rem; align-items:center;">
        <button
          *ngIf="editingId !== note.id"
          (click)="startEdit(note)"
          class="add-button"
          style="padding:.35rem .75rem; font-size:.85rem;"
          title="Redaguoti"
        >
          ✏️ Redaguoti
        </button>

        <button
          (click)="deleteNote(note.id)"
          class="delete-button"
          title="Ištrinti užrašą"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    </div>

    <!-- text (view vs edit) -->
    <p class="note-text" *ngIf="editingId !== note.id">{{ note.text }}</p>
    <textarea
      *ngIf="editingId === note.id"
      [(ngModel)]="editText"
      rows="4"
      class="form-textarea"
      placeholder="Tekstas"
    ></textarea>

    <div class="note-footer" style="display:flex; justify-content:space-between; align-items:center;">
      <span>{{ note.createdAt }}</span>

      <!-- save / cancel only in edit mode -->
      <div *ngIf="editingId === note.id" style="display:flex; gap:.5rem;">
        <button
          class="add-button"
          style="padding:.35rem .75rem; font-size:.85rem; background:linear-gradient(180deg,#10b981,#059669);"
          (click)="saveEdit(note)"
        >
          💾 Išsaugoti
        </button>
        <button
          class="add-button"
          style="padding:.35rem .75rem; font-size:.85rem; background:linear-gradient(180deg,#e5e7eb,#9ca3af); color:#111827;"
          (click)="cancelEdit()"
        >
          ↩️ Atšaukti
        </button>
      </div>
    </div>
  </div>
</div>

      </main>
    </div>
  `,
  styles: [`
    .notes-container {
      min-height: 100vh;
      background: linear-gradient(to bottom right, #eff6ff, #dbeafe, #eef2ff);
    }
    .notes-header { background-color: white; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); border-bottom: 2px solid #3b82f6; }
    .header-content { max-width: 1280px; margin: 0 auto; padding: 1.25rem 1rem; }
    .header-title-wrapper { display: flex; align-items: center; gap: 0.75rem; }
    .header-title { font-size: 1.875rem; font-weight: bold; background: linear-gradient(to right, #2563eb, #4f46e5);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
    .main-content { max-width: 1280px; margin: 0 auto; padding: 2rem 1rem; }
    .add-note-card { background-color: white; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
      padding: 1.5rem; margin-bottom: 2rem; border: 2px solid #bfdbfe; transition: all 0.3s; }
    .add-note-card:hover { border-color: #60a5fa; }
    .add-note-title { font-size: 1.25rem; font-weight: 600; color: #1f2937; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem; }
    .plus-icon { color: #2563eb; }
    .form-group { margin-bottom: 1rem; }
    .form-label { display: block; font-size: 0.875rem; font-weight: 500; color: #374151; margin-bottom: 0.5rem; }
    .form-input, .form-textarea { width: 100%; padding: 0.5rem 1rem; border: 1px solid #93c5fd; border-radius: 0.5rem; outline: none; transition: all 0.2s; box-sizing: border-box; font-family: inherit; }
    .form-input:focus, .form-textarea:focus { box-shadow: 0 0 0 2px #3b82f6; border-color: transparent; }
    .form-textarea { resize: none; }
    .add-button { width: 100%; background: linear-gradient(to right, #3b82f6, #2563eb); color: white; font-weight: 600;
      padding: 0.75rem 1.5rem; border-radius: 0.5rem; border: none; cursor: pointer; transition: all 0.3s; display: flex;
      align-items: center; justify-content: center; gap: 0.5rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
    .add-button:hover { background: linear-gradient(to right, #2563eb, #1d4ed8); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
      transform: translateY(-2px); }
    .notes-count-card { background-color: white; border-radius: 0.5rem; box-shadow: 0 1px 3px 0 rgba(0,0,0,0.1);
      padding: 1rem; display: inline-block; margin-bottom: 1.5rem; }
    .notes-count-text { color: #374151; font-weight: 500; display: flex; align-items: center; gap: 0.5rem; margin: 0; }
    .notes-count-number { color: #2563eb; font-weight: bold; font-size: 1.125rem; }
    .empty-state { background-color: white; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
      padding: 3rem; text-align: center; border: 2px dashed #93c5fd; }
    .empty-icon { font-size: 3.75rem; margin-bottom: 1rem; }
    .empty-title { font-size: 1.25rem; font-weight: 600; color: #374151; margin-bottom: 0.5rem; }
    .empty-description { color: #6b7280; }
    .notes-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
    .note-card { background-color: white; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
      padding: 1.25rem; border-left: 4px solid #3b82f6; transition: all 0.3s; display: flex; flex-direction: column; height: 13rem; }
    .note-card:hover { box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); transform: translateY(-4px); border-left-color: #2563eb; }
    .note-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem; flex-shrink: 0; }
    .note-title { font-size: 1.125rem; font-weight: bold; color: #1f2937; word-break: break-word; flex: 1; overflow: hidden;
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; margin: 0; }
    .delete-button { color: #ef4444; background: none; border: none; padding: 0.5rem; border-radius: 0.5rem; cursor: pointer;
      transition: all 0.2s; flex-shrink: 0; margin-left: 0.5rem; }
    .delete-button:hover { color: #dc2626; background-color: #fef2f2; }
    .note-text { font-size: 0.875rem; color: #4b5563; white-space: pre-wrap; word-break: break-word; flex-grow: 1; overflow-y: auto; margin-bottom: 0.75rem; }
    .note-footer { font-size: 0.75rem; color: #9ca3af; border-top: 1px solid #f3f4f6; padding-top: 0.5rem; margin-top: auto; flex-shrink: 0; }
    @media (max-width: 1024px) { .notes-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 640px) { .notes-grid { grid-template-columns: repeat(1, 1fr); } }
  `]
})
export class AppComponent {
  // UI list
  notes: Array<{ id: string; title: string; text: string; createdAt: string }> = [];

  // create form
  title = '';
  text = '';

  // edit state
  editingId: string | null = null;
  editTitle = '';
  editText = '';

  // ✅ your Realtime DB root (no trailing slash)
  private readonly BASE = 'https://fir-uzduotis-default-rtdb.firebaseio.com';

  constructor(private http: HttpClient) {
    this.loadNotes();
  }

  // ----- READ -----
  loadNotes(): void {
    this.http.get<FirebaseMap | null>(`${this.BASE}/notes.json`).subscribe({
      next: (data) => {
        this.notes = data
          ? Object.entries(data).map(([id, note]) => ({ id, ...note }))
          : [];
      },
      error: (err) => console.error('GET notes failed:', err),
    });
  }

  // ----- CREATE -----
  addNote(): void {
    if (!this.title.trim() || !this.text.trim()) {
      alert('Prašome užpildyti visus laukus!');
      return;
    }

    const payload: NewNote = {
      title: this.title.trim(),
      text: this.text.trim(),
      createdAt: new Date().toLocaleString('lt-LT'),
    };

    this.http.post<{ name: string }>(`${this.BASE}/notes.json`, payload).subscribe({
      next: (res) => {
        const id = res.name;
        this.notes.unshift({ id, ...payload });
        this.title = '';
        this.text = '';
      },
      error: (err) => console.error('POST note failed:', err),
    });
  }

  // ----- DELETE -----
  deleteNote(id: string): void {
    this.http.delete<void>(`${this.BASE}/notes/${id}.json`).subscribe({
      next: () => {
        this.notes = this.notes.filter((n) => n.id !== id);
      },
      error: (err) => console.error('DELETE note failed:', err),
    });
  }

  // ===== UPDATE (Edit) =====

  /** Enter edit mode for a note */
  startEdit(note: { id: string; title: string; text: string }) {
    this.editingId = note.id;
    this.editTitle = note.title;
    this.editText = note.text;
  }

  /** Leave edit mode */
  cancelEdit() {
    this.editingId = null;
    this.editTitle = '';
    this.editText = '';
  }

  /** Save edited values (PATCH on Firebase) */
  saveEdit(note: { id: string }) {
    if (!this.editingId || this.editingId !== note.id) return;

    const patch = {
      title: this.editTitle.trim() || 'Be pavadinimo',
      text: this.editText.trim() || '—',
    };

    this.http.patch<void>(`${this.BASE}/notes/${note.id}.json`, patch).subscribe({
      next: () => {
        const i = this.notes.findIndex((n) => n.id === note.id);
        if (i > -1) this.notes[i] = { ...this.notes[i], ...patch };
        this.cancelEdit();
      },
      error: (err) => console.error('PATCH note failed:', err),
    });
  }
}