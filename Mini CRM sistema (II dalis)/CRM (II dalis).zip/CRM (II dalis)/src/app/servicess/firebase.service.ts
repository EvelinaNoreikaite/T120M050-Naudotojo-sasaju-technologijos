import { Injectable } from '@angular/core';
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, get, remove, push, Database } from 'firebase/database';
import { environment } from '../../environments/environment';
import { Company } from '../models/company';
import { Contact } from '../models/contact';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class DataService {
    private db: Database;
    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$: Observable<boolean> = this.loadingSubject.asObservable();
    
    private errorSubject = new BehaviorSubject<string | null>(null);
    public error$: Observable<string | null> = this.errorSubject.asObservable();
    
    private successSubject = new BehaviorSubject<string | null>(null);
    public success$: Observable<string | null> = this.successSubject.asObservable();

    constructor() {
        // Initialize Firebase
        const app = initializeApp(environment.firebase);
        this.db = getDatabase(app);
        console.log('🔥 Firebase initialized successfully');
    }

    private setLoading(loading: boolean): void {
        this.loadingSubject.next(loading);
    }

    private setError(error: string | null): void {
        this.errorSubject.next(error);
        if (error) {
            setTimeout(() => this.errorSubject.next(null), 5000);
        }
    }

    private setSuccess(message: string | null): void {
        this.successSubject.next(message);
        if (message) {
            setTimeout(() => this.successSubject.next(null), 3000);
        }
    }

    // ==================== COMPANY METHODS ====================

    async getCompanies(): Promise<Company[]> {
        this.setLoading(true);
        this.setError(null);
        
        try {
            const companiesRef = ref(this.db, 'companies');
            const snapshot = await get(companiesRef);
            
            if (snapshot.exists()) {
                const data = snapshot.val();
                const companies = Object.keys(data).map(key => {
                    return new Company({ ...data[key], id: key });
                });
                console.log('✅ Companies loaded from Firebase:', companies.length);
                return companies;
            }
            
            console.log('ℹ️ No companies found in Firebase');
            return [];
        } catch (error: any) {
            const errorMessage = `Klaida kraunant įmones: ${error.message}`;
            console.error('❌', errorMessage);
            this.setError(errorMessage);
            return [];
        } finally {
            this.setLoading(false);
        }
    }

    getCompanyById(id: string): Promise<Company | null> {
        return this.getCompanies().then(companies => {
            return companies.find(c => c.id === id) || null;
        });
    }

    async saveCompany(company: Company): Promise<string> {
        this.setLoading(true);
        this.setError(null);
        
        try {
            company.registracijosLaikas = new Date().toISOString();
            
            let companyId: string;
            
            if (company.id) {
                companyId = company.id;
                const companyRef = ref(this.db, `companies/${companyId}`);
                await set(companyRef, {
                    pavadinimas: company.pavadinimas,
                    kodas: company.kodas,
                    pvmKodas: company.pvmKodas,
                    adresas: company.adresas,
                    elPastas: company.elPastas,
                    telefonas: company.telefonas,
                    registracijosLaikas: company.registracijosLaikas
                });
                console.log('✅ Company updated in Firebase:', companyId);
                this.setSuccess('Įmonė sėkmingai atnaujinta!');
            } else {
                const companiesRef = ref(this.db, 'companies');
                const newCompanyRef = push(companiesRef);
                companyId = newCompanyRef.key!;
                
                await set(newCompanyRef, {
                    pavadinimas: company.pavadinimas,
                    kodas: company.kodas,
                    pvmKodas: company.pvmKodas,
                    adresas: company.adresas,
                    elPastas: company.elPastas,
                    telefonas: company.telefonas,
                    registracijosLaikas: company.registracijosLaikas
                });
                console.log('✅ Company created in Firebase:', companyId);
                this.setSuccess('Įmonė sėkmingai išsaugota!');
            }
            
            return companyId;
        } catch (error: any) {
            const errorMessage = `Klaida saugant įmonę: ${error.message}`;
            console.error('❌', errorMessage);
            this.setError(errorMessage);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async deleteCompany(id: string): Promise<void> {
        this.setLoading(true);
        this.setError(null);
        
        try {
            const companyRef = ref(this.db, `companies/${id}`);
            await remove(companyRef);
            
            const contacts = await this.getContactsByCompany(id);
            for (const contact of contacts) {
                if (contact.id) {
                    await this.deleteContact(contact.id);
                }
            }
            
            console.log('✅ Company deleted from Firebase:', id);
            this.setSuccess('Įmonė sėkmingai ištrinta!');
        } catch (error: any) {
            const errorMessage = `Klaida trinant įmonę: ${error.message}`;
            console.error('❌', errorMessage);
            this.setError(errorMessage);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    // ==================== CONTACT METHODS ====================

    async getContacts(): Promise<Contact[]> {
        this.setLoading(true);
        this.setError(null);
        
        try {
            const contactsRef = ref(this.db, 'contacts');
            const snapshot = await get(contactsRef);
            
            if (snapshot.exists()) {
                const data = snapshot.val();
                const contacts = Object.keys(data).map(key => {
                    return new Contact({ ...data[key], id: key });
                });
                console.log('✅ Contacts loaded from Firebase:', contacts.length);
                return contacts;
            }
            
            console.log('ℹ️ No contacts found in Firebase');
            return [];
        } catch (error: any) {
            const errorMessage = `Klaida kraunant kontaktus: ${error.message}`;
            console.error('❌', errorMessage);
            this.setError(errorMessage);
            return [];
        } finally {
            this.setLoading(false);
        }
    }

    async getContactsByCompany(companyId: string): Promise<Contact[]> {
        try {
            const allContacts = await this.getContacts();
            return allContacts.filter(c => c.companyId === companyId);
        } catch (error: any) {
            console.error('❌ Error filtering contacts:', error);
            return [];
        }
    }

    async saveContact(contact: Contact): Promise<string> {
        this.setLoading(true);
        this.setError(null);
        
        try {
            contact.registracijosLaikas = new Date().toISOString();
            
            const contactsRef = ref(this.db, 'contacts');
            const newContactRef = push(contactsRef);
            const contactId = newContactRef.key!;
            
            await set(newContactRef, {
                companyId: contact.companyId,
                vardas: contact.vardas,
                pavarde: contact.pavarde,
                pareigos: contact.pareigos,
                telefonas: contact.telefonas,
                registracijosLaikas: contact.registracijosLaikas
            });
            
            console.log('✅ Contact created in Firebase:', contactId);
            this.setSuccess('Kontaktas sėkmingai išsaugotas!');
            return contactId;
        } catch (error: any) {
            const errorMessage = `Klaida saugant kontaktą: ${error.message}`;
            console.error('❌', errorMessage);
            this.setError(errorMessage);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async deleteContact(id: string): Promise<void> {
        this.setLoading(true);
        this.setError(null);
        
        try {
            const contactRef = ref(this.db, `contacts/${id}`);
            await remove(contactRef);
            console.log('✅ Contact deleted from Firebase:', id);
            this.setSuccess('Kontaktas sėkmingai ištrintas!');
        } catch (error: any) {
            const errorMessage = `Klaida trinant kontaktą: ${error.message}`;
            console.error('❌', errorMessage);
            this.setError(errorMessage);
            throw error;
        } finally {
            this.setLoading(false);
        }
    }
}