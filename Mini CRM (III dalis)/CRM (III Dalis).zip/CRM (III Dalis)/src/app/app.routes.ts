import { Routes } from '@angular/router';
import { Dashboard } from './components/crm/dashboard/dashboard';
import { CompaniesList } from './components/crm/companies-list/companies-list';
import { CompanyForm } from './components/crm/company-form/company-form';
import { ContactsList } from './components/crm/contacts-list/contacts-list';
import { NewItem } from './components/items/new-item/new-item';
import { Login } from './components/auth/login/login';
import { Register } from './components/auth/register/register';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: Login },
    { path: 'register', component: Register },
    { path: 'dashboard', component: Dashboard, canActivate: [authGuard] },
    { path: 'companies', component: CompaniesList, canActivate: [authGuard] },
    { path: 'companies/create', component: CompanyForm, canActivate: [authGuard] },
    { path: 'companies/edit/:id', component: CompanyForm, canActivate: [authGuard] },
    { path: 'contacts', component: ContactsList, canActivate: [authGuard] },
    { path: 'items/new', component: NewItem, canActivate: [authGuard] }
];