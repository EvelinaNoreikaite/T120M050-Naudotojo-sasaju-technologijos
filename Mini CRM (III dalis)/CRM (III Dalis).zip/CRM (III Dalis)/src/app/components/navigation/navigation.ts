import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { AuthService } from '../../servicess/auth.service';

@Component({
    selector: 'app-navigation',
    standalone: true,
    imports: [RouterLink, RouterLinkActive, CommonModule],
    templateUrl: './navigation.html',
    styleUrl: './navigation.css'
})
export class Navigation {
    userEmail: string = '';

    constructor(
        public authService: AuthService,
        private router: Router
    ) {}

    ngOnInit() {
        this.authService.currentUser$.subscribe(user => {
            this.userEmail = user?.email || '';
        });
    }

    async logout() {
        if (confirm('Ar tikrai norite atsijungti?')) {
            await this.authService.logout();
            this.router.navigate(['/login']);
        }
    }
}