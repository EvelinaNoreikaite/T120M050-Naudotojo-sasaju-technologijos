import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DataService } from '../../../servicess/firebase.service';

@Component({
    selector: 'app-dashboard',
    standalone: true,
    imports: [CommonModule, RouterLink],
    templateUrl: './dashboard.html',
    styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
    totalCompanies: number = 0;
    totalContacts: number = 0;
    isUsingFirebase: boolean = true; // Now using Firebase!
    loading: boolean = false;
    
    private isBrowser: boolean;

    constructor(
        @Inject(PLATFORM_ID) platformId: Object,
        private dataService: DataService
    ) {
        this.isBrowser = isPlatformBrowser(platformId);
    }

    async ngOnInit() {
        if (this.isBrowser) {
            this.dataService.loading$.subscribe(loading => {
                this.loading = loading;
            });
            await this.updateStats();
        }
    }

    async updateStats() {
        if (!this.isBrowser) return;
        
        try {
            const companies = await this.dataService.getCompanies();
            const contacts = await this.dataService.getContacts();
            
            this.totalCompanies = companies.length;
            this.totalContacts = contacts.length;
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }
}