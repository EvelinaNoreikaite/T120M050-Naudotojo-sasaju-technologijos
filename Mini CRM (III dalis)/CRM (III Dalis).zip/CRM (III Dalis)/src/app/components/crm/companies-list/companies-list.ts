import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Company } from '../../../models/company';
import { DataService } from '../../../servicess/firebase.service';

@Component({
    selector: 'app-companies-list',
    standalone: true,
    imports: [CommonModule, RouterLink],
    templateUrl: './companies-list.html',
    styleUrl: './companies-list.css'
})
export class CompaniesList implements OnInit {
    companies: Company[] = [];
    loading: boolean = false;
    error: string | null = null;

    constructor(private dataService: DataService) {}

    async ngOnInit() {
        // Subscribe to loading state
        this.dataService.loading$.subscribe(loading => {
            this.loading = loading;
        });

        // Subscribe to error state
        this.dataService.error$.subscribe(error => {
            this.error = error;
        });

        await this.loadCompanies();
    }

    async loadCompanies() {
        try {
            this.companies = await this.dataService.getCompanies();
        } catch (error) {
            console.error('Error loading companies:', error);
        }
    }

    async deleteCompany(id: string | undefined) {
        if (!id) return;
        
        if (confirm('Ar tikrai norite ištrinti šią įmonę?')) {
            try {
                await this.dataService.deleteCompany(id);
                await this.loadCompanies();
            } catch (error) {
                console.error('Error deleting company:', error);
            }
        }
    }

    viewCompany(company: Company) {
        console.clear();
        console.log('%c╔═══════════════════════════════════════════════╗', 'color: #3c8dbc; font-weight: bold');
        console.log('%c        ĮMONĖS DUOMENYS', 'color: #00a65a; font-size: 16px; font-weight: bold');
        console.log('%c╠═══════════════════════════════════════════════╣', 'color: #3c8dbc; font-weight: bold');
        console.table(company);
        console.log('%c╚═══════════════════════════════════════════════╝', 'color: #3c8dbc; font-weight: bold');
    }
}