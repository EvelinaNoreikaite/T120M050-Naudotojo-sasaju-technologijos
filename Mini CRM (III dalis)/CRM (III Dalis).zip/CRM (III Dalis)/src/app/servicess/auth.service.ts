import { Injectable } from '@angular/core';
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private auth;
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$: Observable<User | null> = this.currentUserSubject.asObservable();
  
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$: Observable<boolean> = this.loadingSubject.asObservable();
  
  private errorSubject = new BehaviorSubject<string | null>(null);
  public error$: Observable<string | null> = this.errorSubject.asObservable();
  
  private successSubject = new BehaviorSubject<string | null>(null);
  public success$: Observable<string | null> = this.successSubject.asObservable();

  constructor() {
    // Initialize Firebase FIRST
    const app = initializeApp(environment.firebase);
    // Then get auth
    this.auth = getAuth(app);
    
    // Listen to auth state changes
    onAuthStateChanged(this.auth, (user) => {
      this.currentUserSubject.next(user);
      console.log('👤 Auth state changed:', user?.email || 'Not logged in');
    });
  }

  private setLoading(loading: boolean): void {
    this.loadingSubject.next(loading);
  }

  private setError(error: string | null): void {
    this.errorSubject.next(error);
    if (error) {
      setTimeout(() => this.errorSubject.next(null), 5000);
    }
  }

  private setSuccess(message: string | null): void {
    this.successSubject.next(message);
    if (message) {
      setTimeout(() => this.successSubject.next(null), 3000);
    }
  }

  // Get current user
  getCurrentUser(): User | null {
    return this.auth.currentUser;
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return this.auth.currentUser !== null;
  }

  // Register new user
  async register(email: string, password: string): Promise<boolean> {
    this.setLoading(true);
    this.setError(null);
    
    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
      console.log('✅ User registered:', userCredential.user.email);
      this.setSuccess('Registracija sėkminga! Galite prisijungti.');
      return true;
    } catch (error: any) {
      console.error('❌ Registration error:', error);
      this.setError(this.getErrorMessage(error.code));
      return false;
    } finally {
      this.setLoading(false);
    }
  }

  // Login user
  async login(email: string, password: string): Promise<boolean> {
    this.setLoading(true);
    this.setError(null);
    
    try {
      const userCredential = await signInWithEmailAndPassword(this.auth, email, password);
      console.log('✅ User logged in:', userCredential.user.email);
      this.setSuccess('Sėkmingai prisijungėte!');
      return true;
    } catch (error: any) {
      console.error('❌ Login error:', error);
      this.setError(this.getErrorMessage(error.code));
      return false;
    } finally {
      this.setLoading(false);
    }
  }

  // Logout user
  async logout(): Promise<void> {
    this.setLoading(true);
    
    try {
      await signOut(this.auth);
      console.log('✅ User logged out');
      this.setSuccess('Sėkmingai atsijungėte!');
    } catch (error: any) {
      console.error('❌ Logout error:', error);
      this.setError('Klaida atsijungiant');
    } finally {
      this.setLoading(false);
    }
  }

  // Get user-friendly error messages
  private getErrorMessage(errorCode: string): string {
    switch (errorCode) {
      case 'auth/email-already-in-use':
        return 'Šis el. paštas jau naudojamas';
      case 'auth/invalid-email':
        return 'Neteisingas el. pašto formatas';
      case 'auth/operation-not-allowed':
        return 'Operacija neleidžiama';
      case 'auth/weak-password':
        return 'Slaptažodis per silpnas (min. 6 simboliai)';
      case 'auth/user-disabled':
        return 'Šis vartotojas yra išjungtas';
      case 'auth/user-not-found':
        return 'Vartotojas nerastas';
      case 'auth/wrong-password':
        return 'Neteisingas slaptažodis';
      case 'auth/invalid-credential':
        return 'Neteisingi prisijungimo duomenys';
      case 'auth/too-many-requests':
        return 'Per daug bandymų. Pabandykite vėliau';
      default:
        return 'Įvyko klaida. Bandykite dar kartą';
    }
  }
}