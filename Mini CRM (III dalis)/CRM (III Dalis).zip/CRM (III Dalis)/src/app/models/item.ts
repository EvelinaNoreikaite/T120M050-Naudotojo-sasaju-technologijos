export class Item{
    public inv_number:number|null=null;
    public name:String|null=null;
    public locations:String[]=[];
}