export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyC7YF2r5_5qAzWh6EL2-TBEu8t9R6q9rIY",
    authDomain: "crmsistema-211e8.firebaseapp.com",
    databaseURL: "https://crmsistema-211e8-default-rtdb.firebaseio.com",
    projectId: "crmsistema-211e8",
    storageBucket: "crmsistema-211e8.firebasestorage.app",
    messagingSenderId: "458723833553",
    appId: "1:458723833553:web:298a5825c1a1819e6d77f0",
    measurementId: "G-0WFC3MD752"
  }
};