import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { Skaiciuotuvas } from './skaiciuotuvas';

describe('Skaiciuotuvas Component', () => {
  let component: Skaiciuotuvas;
  let fixture: ComponentFixture<Skaiciuotuvas>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [Skaiciuotuvas]
    }).compileComponents();

    fixture = TestBed.createComponent(Skaiciuotuvas);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should correctly calculate BMI', () => {
    component.height = 180;
    component.weight = 75;
    component.skaiciuotiBMI();
    expect(component.bmi).toBeCloseTo(23.15, 2);
  });

  it('should correctly assign BMI category', () => {
    component.bmi = 17.5;
    component.skaiciuotiBMI();
    expect(component.bmiCategory).toBeDefined();
  });
});
