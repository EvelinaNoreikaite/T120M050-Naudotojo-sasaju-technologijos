import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-skaiciuotuvas',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './skaiciuotuvas.html',
  styleUrls: ['./skaiciuotuvas.css']
})
export class Skaiciuotuvas {
  height: number | null = null;
  weight: number | null = null;
  bmi: number | null = null;
  bmiCategory: string = '';
  risk: string = '';
  color: string = '#2f80ed'; // numatyta mėlyna

  skaiciuotiBMI() {
    if (!this.height || !this.weight) return;

    const heightInMeters = this.height / 100;
    this.bmi = this.weight / (heightInMeters * heightInMeters);

    if (this.bmi < 18.5) {
      this.bmiCategory = 'Per mažas svoris';
      this.risk = 'Padidėjusi, būtina pasitarti su gydytoju';
      this.color = '#f5b700'; // geltona
    } 
    else if (this.bmi < 25) {
      this.bmiCategory = 'Normalus svoris';
      this.risk = 'Nėra';
      this.color = '#28a745'; // žalia
    } 
    else if (this.bmi < 30) {
      this.bmiCategory = 'Antsvoris';
      this.risk = 'Nedidelė, stengtis, kad nedidėtų';
      this.color = '#ffc107'; // gelsvai oranžinė
    } 
    else if (this.bmi < 35) {
      this.bmiCategory = 'I° nutukimas';
      this.risk = 'Padidėjusi, būtina mažinti svorį';
      this.color = '#fd7e14'; // oranžinė
    } 
    else if (this.bmi < 40) {
      this.bmiCategory = 'II° nutukimas';
      this.risk = 'Didelė, būtina mažinti svorį';
      this.color = '#dc3545'; // raudona
    } 
    else {
      this.bmiCategory = 'III° (liguistas) nutukimas';
      this.risk = 'Labai didelė, būtina mažinti';
      this.color = '#b30000'; // tamsiai raudona
    }
  }
}
