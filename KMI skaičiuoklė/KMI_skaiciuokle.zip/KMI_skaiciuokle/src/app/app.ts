import { Component, signal } from '@angular/core';
import { Skaiciuotuvas } from './skaiciuotuvas/skaiciuotuvas';

@Component({
  selector: 'app-root',
  standalone: true,                 // ← important
  imports: [Skaiciuotuvas],         // ← no RouterOutlet since we don't use it
  templateUrl: './app.html',
  styleUrls: ['./app.css']          // ← plural
})
export class AppComponent {
  title = signal('skaiciuotuvas2025');
}
